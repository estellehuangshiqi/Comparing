#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF对比工具包
"""

from .pdf_compare import PDFComparer, compare_pdfs

__version__ = "1.0.0"
__all__ = ["PDFComparer", "compare_pdfs"]
