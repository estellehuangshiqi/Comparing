#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF对比工具 - 生成带修订标记的Word文档
"""

import fitz  # PyMuPDF
from docx import Document
from docx.shared import RGBColor, Pt
from docx.enum.text import WD_COLOR_INDEX
import difflib
import sys
import os


class PDFComparer:
    """PDF文档对比器"""

    def __init__(self):
        self.deleted_color = RGBColor(255, 0, 0)  # 红色-删除
        self.inserted_color = RGBColor(0, 0, 255)  # 蓝色-插入
        self.normal_color = RGBColor(0, 0, 0)      # 黑色-正常

    def extract_text_by_lines(self, pdf_path):
        """
        从PDF中提取文本，按行组织
        保留段落结构信息
        """
        doc = fitz.open(pdf_path)
        lines = []

        for page_num in range(len(doc)):
            page = doc[page_num]
            text = page.get_text()

            # 按行分割，保留空行信息
            page_lines = text.split('\n')
            for line in page_lines:
                stripped = line.strip()
                # 保留非空行和作为段落分隔的空行
                if stripped or (lines and lines[-1].strip()):
                    lines.append(line)

        doc.close()
        return lines

    def normalize_text(self, text):
        """
        标准化文本用于对比
        去除多余空白但保留结构
        """
        # 统一空白字符
        text = ' '.join(text.split())
        return text.strip()

    def compute_diff(self, old_lines, new_lines):
        """
        计算文本差异
        返回差异操作列表: (operation, text)
        operation: 'equal', 'delete', 'insert', 'replace'
        """
        # 使用SequenceMatcher进行行级对比
        sm = difflib.SequenceMatcher(None, old_lines, new_lines)
        operations = []

        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == 'equal':
                # 完全相同的行
                for line in old_lines[i1:i2]:
                    operations.append(('equal', line))
            elif tag == 'delete':
                # 删除的行
                for line in old_lines[i1:i2]:
                    operations.append(('delete', line))
            elif tag == 'insert':
                # 插入的行
                for line in new_lines[j1:j2]:
                    operations.append(('insert', line))
            elif tag == 'replace':
                # 替换的行 - 需要进一步进行字符级对比
                old_text = '\n'.join(old_lines[i1:i2])
                new_text = '\n'.join(new_lines[j1:j2])

                # 字符级差异分析
                char_ops = self._compute_char_diff(old_text, new_text)
                operations.extend(char_ops)

        return operations

    def _compute_char_diff(self, old_text, new_text):
        """
        字符级差异计算
        精确识别文本中的插入和删除
        """
        sm = difflib.SequenceMatcher(None, old_text, new_text)
        operations = []

        current_equal = []
        current_delete = []
        current_insert = []

        for tag, i1, i2, j1, j2 in sm.get_opcodes():
            if tag == 'equal':
                # 如果有待处理的删除/插入，先输出
                if current_delete:
                    operations.append(('delete', ''.join(current_delete)))
                    current_delete = []
                if current_insert:
                    operations.append(('insert', ''.join(current_insert)))
                    current_insert = []

                old_part = old_text[i1:i2]
                # 检查是否包含换行，需要分割
                if '\n' in old_part:
                    parts = old_part.split('\n')
                    for i, part in enumerate(parts):
                        if part or i < len(parts) - 1:
                            operations.append(('equal', part))
                            if i < len(parts) - 1:
                                operations.append(('equal', '\n'))
                else:
                    operations.append(('equal', old_part))

            elif tag == 'delete':
                deleted = old_text[i1:i2]
                # 处理换行
                if '\n' in deleted:
                    parts = deleted.split('\n')
                    for i, part in enumerate(parts):
                        if part:
                            current_delete.append(part)
                        if i < len(parts) - 1:
                            if current_delete:
                                operations.append(('delete', ''.join(current_delete)))
                                current_delete = []
                            operations.append(('delete', '\n'))
                else:
                    current_delete.append(deleted)

            elif tag == 'insert':
                inserted = new_text[j1:j2]
                # 处理换行
                if '\n' in inserted:
                    parts = inserted.split('\n')
                    for i, part in enumerate(parts):
                        if part:
                            current_insert.append(part)
                        if i < len(parts) - 1:
                            if current_insert:
                                operations.append(('insert', ''.join(current_insert)))
                                current_insert = []
                            operations.append(('insert', '\n'))
                else:
                    current_insert.append(inserted)

        # 输出剩余的操作
        if current_delete:
            operations.append(('delete', ''.join(current_delete)))
        if current_insert:
            operations.append(('insert', ''.join(current_insert)))

        return operations

    def merge_adjacent_operations(self, operations):
        """
        合并相邻的相同类型操作，优化显示
        """
        if not operations:
            return operations

        merged = []
        current_op = operations[0][0]
        current_text = operations[0][1]

        for op, text in operations[1:]:
            if op == current_op:
                # 合并文本，处理换行
                if current_text.endswith('\n') or text.startswith('\n'):
                    current_text += text
                else:
                    current_text += text
            else:
                # 保存当前操作，开始新操作
                # 清理连续的换行
                cleaned_text = self._clean_newlines(current_text)
                if cleaned_text or current_op == 'equal':
                    merged.append((current_op, cleaned_text))
                current_op = op
                current_text = text

        # 处理最后一个操作
        cleaned_text = self._clean_newlines(current_text)
        if cleaned_text or current_op == 'equal':
            merged.append((current_op, cleaned_text))

        return merged

    def _clean_newlines(self, text):
        """清理多余的换行符"""
        # 保留有意义的换行，去除连续多个换行
        lines = text.split('\n')
        cleaned_lines = []
        empty_count = 0

        for line in lines:
            if line.strip() == '':
                empty_count += 1
                if empty_count <= 2:  # 最多保留2个空行
                    cleaned_lines.append(line)
            else:
                empty_count = 0
                cleaned_lines.append(line)

        return '\n'.join(cleaned_lines)

    def create_word_with_changes(self, operations, output_path):
        """
        创建带修订标记的Word文档
        """
        doc = Document()

        # 设置默认字体
        style = doc.styles['Normal']
        font = style.font
        font.name = 'Arial'
        font.size = Pt(11)

        current_paragraph = doc.add_paragraph()
        current_run = None

        for op, text in operations:
            # 处理换行 - 分割文本
            parts = text.split('\n')

            for i, part in enumerate(parts):
                if i > 0:
                    # 遇到换行，创建新段落
                    current_paragraph = doc.add_paragraph()

                if not part and i < len(parts) - 1:
                    # 空行（非最后）
                    continue

                if not part:
                    continue

                # 创建文本运行
                run = current_paragraph.add_run(part)

                if op == 'delete':
                    # 删除的内容：红色+删除线
                    run.font.color.rgb = self.deleted_color
                    run.font.strike = True
                elif op == 'insert':
                    # 插入的内容：蓝色+下划线
                    run.font.color.rgb = self.inserted_color
                    run.font.underline = True
                else:
                    # 未修改的内容：正常黑色
                    run.font.color.rgb = self.normal_color

        # 保存文档
        doc.save(output_path)
        print(f"文档已保存至: {output_path}")

    def compare(self, old_pdf_path, new_pdf_path, output_path):
        """
        主对比函数
        """
        print(f"正在对比文档...")
        print(f"原文档: {old_pdf_path}")
        print(f"新文档: {new_pdf_path}")

        # 检查文件是否存在
        if not os.path.exists(old_pdf_path):
            raise FileNotFoundError(f"找不到原文档: {old_pdf_path}")
        if not os.path.exists(new_pdf_path):
            raise FileNotFoundError(f"找不到新文档: {new_pdf_path}")

        # 提取文本
        print("提取原文档文本...")
        old_lines = self.extract_text_by_lines(old_pdf_path)

        print("提取新文档文本...")
        new_lines = self.extract_text_by_lines(new_pdf_path)

        print("计算差异...")
        operations = self.compute_diff(old_lines, new_lines)

        print("优化差异显示...")
        operations = self.merge_adjacent_operations(operations)

        # 统计信息
        delete_count = sum(1 for op, _ in operations if op == 'delete')
        insert_count = sum(1 for op, _ in operations if op == 'insert')
        equal_count = sum(1 for op, _ in operations if op == 'equal')

        print(f"统计: {delete_count} 处删除, {insert_count} 处插入, {equal_count} 处未修改")

        # 生成Word文档
        print("生成Word文档...")
        self.create_word_with_changes(operations, output_path)

        return {
            'deletions': delete_count,
            'insertions': insert_count,
            'unchanged': equal_count
        }


def compare_pdfs(old_pdf_path, new_pdf_path, output_path):
    """
    便捷的对比函数
    """
    comparer = PDFComparer()
    return comparer.compare(old_pdf_path, new_pdf_path, output_path)


def main():
    """命令行入口"""
    if len(sys.argv) != 4:
        print("用法: python pdf_compare.py <旧PDF> <新PDF> <输出Word>")
        print("示例: python pdf_compare.py old.pdf new.pdf output.docx")
        sys.exit(1)

    old_pdf = sys.argv[1]
    new_pdf = sys.argv[2]
    output_docx = sys.argv[3]

    try:
        stats = compare_pdfs(old_pdf, new_pdf, output_docx)
        print("\n对比完成!")
        print(f"删除: {stats['deletions']} 处")
        print(f"插入: {stats['insertions']} 处")
        print(f"未修改: {stats['unchanged']} 处")
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
