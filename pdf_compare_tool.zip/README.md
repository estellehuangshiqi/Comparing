# PDF对比工具 (PDF Compare Tool)

一个Python工具，用于对比两个PDF文档的差异，并生成带有修订标记（Track Changes）的Word文档。

## 功能特点

- 逐行对比PDF文本内容
- 智能识别实际修改内容（插入/删除）
- 生成带修订标记的Word文档
- 保留文档原有格式
- 未修改内容不显示为修订

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 命令行使用

```bash
python src/pdf_compare.py old.pdf new.pdf output.docx
```

### 作为模块使用

```python
from src.pdf_compare import compare_pdfs

compare_pdfs("old.pdf", "new.pdf", "output.docx")
```

## 项目结构

```
pdf_compare_tool/
├── src/
│   └── pdf_compare.py    # 主程序
├── tests/                # 测试文件
├── examples/             # 示例PDF
├── requirements.txt      # 依赖列表
└── README.md            # 说明文档
```

## 修订标记说明

- **删除内容**：红色删除线标记
- **插入内容**：蓝色下划线标记
- **未修改内容**：正常黑色文本

## 许可证

MIT License
