#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
使用示例：如何生成测试PDF并对比
"""

from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from src.pdf_compare import compare_pdfs
import os

def create_sample_pdf(text, output_path):
    """创建示例PDF文件"""
    c = canvas.Canvas(output_path, pagesize=A4)
    width, height = A4

    # 设置字体
    c.setFont("Helvetica", 12)

    # 写入文本
    y = height - 50
    for line in text.split('\n'):
        if y < 50:  # 新页面
            c.showPage()
            c.setFont("Helvetica", 12)
            y = height - 50
        c.drawString(50, y, line)
        y -= 20

    c.save()
    print(f"已创建: {output_path}")

if __name__ == "__main__":
    # 读取示例文本
    with open("examples/old_text.txt", "r", encoding="utf-8") as f:
        old_text = f.read()

    with open("examples/new_text.txt", "r", encoding="utf-8") as f:
        new_text = f.read()

    # 创建PDF文件
    create_sample_pdf(old_text, "examples/old.pdf")
    create_sample_pdf(new_text, "examples/new.pdf")

    # 进行对比
    print("\n开始对比...")
    stats = compare_pdfs("examples/old.pdf", "examples/new.pdf", "examples/comparison.docx")

    print("\n对比统计:")
    print(f"- 删除: {stats['deletions']} 处")
    print(f"- 插入: {stats['insertions']} 处")
    print(f"- 未修改: {stats['unchanged']} 处")
    print("\n结果已保存至: examples/comparison.docx")
